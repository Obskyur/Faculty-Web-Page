# Faculty Web Page
This web application is designed using Vite and TailwindCSS
## To get started
1. Unzip folder and open in terminal
2. Run `npm install` to install dependencies
3. Run `npm run dev` to begin localhost server
4. Navigate to server URL to view webpage.
**Design was made for static rendering in 1080p (1920x1080)**
- You may have to go to developer mode and set custom window dimensions to view this properly.